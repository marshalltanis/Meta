# LocalVPN
A packet interceptor for Android built on top of VpnService

License: Apache v2.0

Early alpha, will eat your cat!
